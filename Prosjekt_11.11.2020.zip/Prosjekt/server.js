const express = require('express');                 // Eases the use of Node.js
const socket = require('socket.io');                // Websocket event handling
const bodyParser = require('body-parser');          // For parsing JSON and data structures
// General Node.js server setup with help of Express module
const port = 80;

var app = express();
app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({ extended: true }));

// Static files
app.use('/assets', express.static('assets'));

// Start listening to reqs
var server = app.listen(port, function() {
    console.log('%s Listening for requests on port %d...', Date().toString(), port);
});

//Web index html:
app.get('/', (req, res) => {
  console.log(Date().toString(), "Requested URL: ", req.url);
  res.render('index'); 
});

//Web index html:
app.get('/index.ejs', (req, res) => {
  console.log(Date().toString(), "Requested URL: ", req.url);
  res.render('index'); 
});

//About html:
app.get('/about.ejs', (req, res) => {
  console.log(Date().toString(), "Requested URL: ", req.url);
  res.render('about');
});

//help html:
app.get('/help.ejs', (req, res) => {
  console.log(Date().toString(), "Requested URL: ", req.url);
  res.render('help');
});

//kontroll html:
app.get('/kontroll.ejs', (req, res) => {
  console.log(Date().toString(), "Requested URL: ", req.url);
  res.render('kontroll');
});

//logg inn html:
app.get('/loginnpage.ejs', (req, res) => {
  console.log(Date().toString(), "Requested URL: ", req.url);
  res.render('loginnpage');
});

//sign-in html:
app.get('/sign-in.ejs', (req, res) => {
  console.log(Date().toString(), "Requested URL: ", req.url);
  res.render('sign-in');
});

//Sende-Motta data:
var io = socket(server);
io.on("connection", socket => {

    //Esp-data
    socket.on("Data-from-mcu", data => {
      console.log(data)
      socket.broadcast.emit("temp-sensor", data);
      })
})