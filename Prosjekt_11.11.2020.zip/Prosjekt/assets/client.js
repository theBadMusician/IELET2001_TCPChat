//const io = require("socket.io-client");
const socket = io.connect('/');
var dataContainer = document.getElementById("sensor_data")

//Temp-value:
socket.on("temp-sensor", data => {
  console.log("Received data: " + data)
  var temp_data = data;
  dataContainer.innerText = "Received data:"+ temp_data;
  //appendMessage('Data:', data)
})



//funksjon for å få vise tallene i en div.
/*function appendMessage(temp_data) {
  dataContainer.innerText = temp_data;
}*/
//Bruke WSAD tastene til å styre zumobilen
/*
window.addEventsListnener("Keyboard", Keypress, false)

function Keypress(key){
if (key.keyCode == "38") {
	

}
if (key.keyCode == "39"){
}
if (key.keyCode == "37"){


}
if (key.keyCode == "40") {
    
}
}*/
