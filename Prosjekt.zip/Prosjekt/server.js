const express = require('express');                 // Eases the use of Node.js
const socket = require('socket.io');                // Websocket event handling
const bodyParser = require('body-parser');          // For parsing JSON and data structures

// General Node.js server setup with help of Express module
const port = 80;

var app = express();
app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({ extended: true }));

// Static files
app.use('/assets', express.static('assets'));

// Start listening to reqs
var server = app.listen(port, function() {
    console.log('%s Listening for requests on port %d...', Date().toString(), port);
});

//Web html:
app.get('/', (req, res) => {
  console.log(Date().toString(), "Requested URL: ", req.url);
  res.render('index');
});

//
const users = {}

var io = socket(server);
io.on("connection", socket => {

  socket.on("new-user", name => {
    users[socket.id]  = name
    socket.broadcast.emit("user-connection", name)
      })

  socket.on("disconnect", () => {
    
    socket.broadcast.emit("user-disconnection", users[socket.id])
    delete users[socket.id] 
      })

  socket.on("send-chat-message", message => {
    console.log(message)
    socket.broadcast.emit("chat-message", { message: message, name :
      users[socket.id] })
    })

    //Esp-data
    socket.on("Data-from-mcu", data => {
      console.log(data)
      socket.broadcast.emit("temp-sensor", data);
      })
})

