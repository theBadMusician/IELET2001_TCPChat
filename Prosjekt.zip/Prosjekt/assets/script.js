const socket = io("/");
const messageContainer = document.getElementById("message-container")
const messageForm = document.getElementById("send-container")
const messageInput = document.getElementById("message-input")

const name = prompt("what is your name?")
appendMessage("you joined")
socket.emit("new-user", name)

socket.on("chat-message", data => {
  appendMessage(`${data.name}: ${data.message}`)
})
socket.on("user-connection", name => {
  appendMessage(`${name} joined!`)
})

//Temp-value:
socket.on("temp-sensor", data => {
  appendMessage('Temperaturen:', data)
})

socket.on("user-disconnection", name => {
  appendMessage(`${name} disconnected!`)
})

messageForm.addEventListener('submit', e => {
  e.preventDefault()
  const message = messageInput.value
  appendMessage(`You: ${message}`)
  socket.emit('send-chat-message', message)
  messageInput.value = ''
})

function appendMessage(message) {
  const messageElement = document.createElement('div')
  messageElement.innerText = message
  messageContainer.append(messageElement)
}

